<?php
include '../depend/connectfile.php';
 $date = date("Y-m-d H:i:s");
$vehicle = $_POST["vehicle"];
$route = $_POST["route"];
$routeprice = $_POST["routeprice"];
$pass = $_POST["pass"];
$water2 = $_POST["water2"];
$commission2 = $_POST["commission2"];
$fare = $_POST["fare"];
$income = $_POST["income"];


$sql = $conn->query("INSERT INTO trip(vehicle, route, pass, tfare, water, commission, income,datecreated) VALUES ('$vehicle','$route','$pass','$fare','$water2','$commission2','$income','$date')");

if( $sql) {
    echo   $status = 'ok';
  }
  else{
    echo  $status = 'err';
	
  }
 //echo $status;die; 
?>