<?php 
include '../layout/header.php';
include '../depend/connectfile.php';
if($_GET["action"] == "v_view"){
     $id = $_GET["id"];
    $res=mysqli_query($conn, "SELECT vehicles.plates, vehicles.make, routes.name, trip.pass, trip.tfare, trip.water, trip.commission, trip.income, trip.datecreated, trip.indextrip FROM trip 
    JOIN vehicles ON vehicles.id_vehicle =trip.vehicle
    JOIN routes ON routes.indexr=trip.route
    WHERE vehicles.id_vehicle=$id
    ");
    
}
 ?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Shareholder Details  </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Vehicle profile</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-12">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body">              
                 <div class="row">
                     <div class="col-md-6">
                         <div class="form-group">
                             <label></label>
                         </div>
                     </div>
                     <div class="col-md-6">
                         
                     </div>
                 </div>         
            </div>
            <!-- /.box-body -->
          </div>
      </div>

      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->

    <!-- Modal -->

  </div>
<?php 
include '../layout/footer.php';
 ?>
