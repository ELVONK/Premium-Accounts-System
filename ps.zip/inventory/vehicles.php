<?php include '../layout/prof.php';?>
<?php include '../layout/header.php';?>
<?php include '../layout/leftbar.php'; ?>
 <script src="jquery-3.3.1.min.js"></script>

<script>
function addvehicle(){
  var make = $("#make").val();  
  var plates= $("#plates").val();
  var owner= $("#owner").val();
  var driver = $("#driver").val(); 
  var route = $("#route").val(); 

      if(plates.trim() == '' ){
          alert('Plates required.');
          $('#plates').focus();
          return false;
      }  
      if(route.trim() == '' ){
          alert('route required.');
          $('#route').focus();
          return false;
      }
      else{
        $.ajax({
            type:'POST',
            url:'addvehiclesajax.php',
            data:'contactFrmSubmit=1&make='+make+'&plates='+plates+'&owner='+owner+'&driver='+driver+'&route='+route,
            beforeSend: function () {
                $('.modal-body').css('opacity', '');
                $("#btnSubmit").attr("disabled", true);                
            },
            success:function(msg1){
                if(msg1 == 'ok'){        
$('.statusMsg1').html('<div class="row" style="margin-right: 0px;padding-left: 12px;" ><div class="col-md-10" style="background-color:green;color:#fff;text-align:left;height:30px"><h5>Vehicle Saved</h5></div></div>');
  location.reload();
 }      
     else{
$(msg1 == 'err').html('<div align="center" class="row" style="margin-right: 0px;padding-left: 12px;" ><div class="col-md-10" style="background-color:green;color:#fff;text-align:left;height:30px"><h5>Vehicle Saved</h5></div></div>');
         // $('.statusMsg1').html('<span style="color:red;"><h5>ocurrió algún problema.</h5></span>');
               location.reload();
                }
                $('.submitBtn').removeAttr("disabled");
                $('.modal-body').css('opacity', '');
                $("#btnSubmit").attr("disabled", true);
             }
        });
    }
}
</script>
<div class="wrapper">
  	<div class="content-wrapper">
	    <section class="content-header">
	      <h1>
	        Vehicle        
	      </h1>
	      <ol class="breadcrumb">
	        <li><a href="../dashboard.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
	        <li class="active">Vehicle</li>
	      </ol>
	    </section>
	    <!-- Main content -->
	    <section class="content">
	        <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <a href=""  data-toggle="modal" data-target="#modal-default">
                      <div class="info-box">
                        <span class="info-box-icon bg-aqua"><i class="fa fa-bus"></i></span>
                        <div class="info-box-content">
                          <span class="info-box-text">Add Vehicle</span>
                          <span class="info-box-number">90</span>
                        </div>
                      </div>
                    </a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="box box-succes">
                        <div class="box-header">
                          <h3 class="box-title">Driver's List</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                      <th>#</th>
                                      <th>Make</th>
                                      <th>Plates</th>
                                      <th>Owner</th>
                                      <th>Driver</th>
                                       <th>Route</th>
                                      <th>View</th>
                                     
                                    </tr>
                                </thead>
                                <tbody>
                                     <?php	
            		                include '../depend/connectfile.php';
                                    $res=mysqli_query($conn, "SELECT vehicles.make, vehicles.plates, shareholders.full_name, drivers.driver_name, routes.name, vehicles.id_vehicle from vehicles 
                                    JOIN drivers ON drivers.indexx=vehicles.driver 
                                    JOIN shareholders ON vehicles.owner=shareholders.indexx JOIN routes ON vehicles.route=routes.indexr");
            			            $i = 1;
            			            while ($account = mysqli_fetch_assoc($res)) { ?>
            			        <tr>
            		            	<td><?php echo $i; ?></td>
            		            	<td><?php echo $account['make']; ?></td>
            		            	<td><?php echo $account['plates']; ?></td>
            		                <td><?php echo $account['full_name']; ?></td>
            		                <td><?php echo $account['driver_name']; ?></td>
            		                <td><?php echo $account['name']; ?></td>
            						<td>		
            	                    <a  href="<?php echo 'viewvehicledetails.php?action=v_view&id='; ?><?php echo $account['id_vehicle']; ?>" ><i class="fa fa-expand"></i></a>
            	                    </td>
            	                    
            		            </tr>
            		            <?php $i++; } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
	    </section>
	</div>
</div>
<div class="modal fade" id="modal-default">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">Add Vehicle</h4>
            </div>
            <div class="modal-body">
                <form method="POST" name="form" action=""> 
                    <div class="modal-body">                    
                            <div class="row">
                                <div class="col-xs-6">
                                <label>Make</label>
                                  <input type="text"class="form-control" name="make" id="make" placeholder="Toyota Hiace" required>
                                </div>
                                <div class="col-xs-6">                         
                                  <label>Plate Number</label><br>
                                  <input class="form-control" id="plates" name="plates" required="required" type="email" placeholder="KCU 948K">
                                </div>
                            </div> 
                            <div class="row">
                                <div class="col-xs-6">
                                  <label>Owner</label>
                                  <select id="owner" name="owner" class="form-control" style="height: 35px !important;" required="required">
                                      <option value="">Select Owner</option>
                                      <?php	
            		                include '../depend/connectfile.php';
                                    $ress=mysqli_query($conn, "SELECT * FROM shareholders where full_name!='' order by full_name asc");
            			            while ($accounts = mysqli_fetch_assoc($ress)) { ?>
            			            <option value="<?php print $accounts['indexx']; ?>"><?php echo $accounts['full_name']; ?></option>
            			             <?php  } ?>
                                  </select>
                                </div>
                                 <div class="col-xs-6">                         
                                  <label>Driver</label><br>
                                  <select id="driver" name="driver" class="form-control" style="height: 35px !important;">
                                      <option value="">Select Driver</option>
                                      <?php	
                		                include '../depend/connectfile.php';
                                        $res=mysqli_query($conn, "SELECT * FROM drivers where driver_name!='' order by driver_name asc");
                			            while ($account = mysqli_fetch_assoc($res)) { ?>
                			            <option value="<?php print $account['indexx']; ?>"><?php echo $account['driver_name']; ?></option>
                			         <?php  } ?>
                                  </select>
                                </div>
                                
                                <div class="col-xs-6">                         
                                  <label>Route</label><br>
                                  <select id="route" name="route" class="form-control" style="height: 35px !important;">
                                      <option value="">Select Route</option>
                                      <?php	
                		                include '../depend/connectfile.php';
                                        $route=mysqli_query($conn, "SELECT * FROM routes where name!='' order by name asc");
                			            while ($routes = mysqli_fetch_assoc($route)) { ?>
                			            <option value="<?php print $routes['indexr']; ?>"><?php echo $routes['name']; ?></option>
                			         <?php  } ?>
                                  </select>
                                </div>
                                
                                
                            </div>
                           <div><p class="statusMsg1"></p></div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" name="sub2" id="sub2" class="btn btn-success pull-right"  onclick="addvehicle()">
                                <span class="glyphicon glyphicon-ok-sign"></span>
                                  Save
                              </button>
                        <button type="button" data-dismiss="modal" aria-label="Close" class="btn btn-warning pull-left">
                          
                            Cancel
                        </button>
                      </div>
                  </form>
              </div>
            </div>
        </div>
    </div>


<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({ timePicker: true, timePickerIncrement: 30, locale: { format: 'MM/DD/YYYY hh:mm A' }})
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass   : 'iradio_minimal-blue'
    })
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass   : 'iradio_minimal-red'
    })
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    })

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  })
</script>
<?php 
include '../layout/scripts.php';
include '../layout/footer.php';
 ?>