<?php
include '../depend/connectfile.php';
 $date = date("Y-m-d H:i:s");
$route= $_POST["route"];
$parcel_desc = $_POST["parcel_desc"];
$paid_amount = $_POST["paid_amount"];


$sql = $conn->query("INSERT INTO parcels(route, parcel_desc, paid_amount,datereceived) VALUES ('$route','$parcel_desc','$paid_amount','$date')");

if( $sql) {
    echo   $status = 'ok';
  }
  else{
    echo  $status = 'err';
	
  }
 //echo $status;die; 
?>