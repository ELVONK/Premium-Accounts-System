<?php 
include '../layout/header.php';
include '../depend/connectfile.php';
if($_GET["action"] == "v_view"){
     $id = $_GET["id"];
    $sql = $conn->query("SELECT * FROM vehicles WHERE id_vehicle='$id'");
    $res=mysqli_query($conn, "SELECT vehicles.plates, vehicles.make, routes.name, trip.pass, trip.tfare, trip.water, trip.commission, trip.income, trip.datecreated, trip.indextrip FROM trip 
    JOIN vehicles ON vehicles.id_vehicle =trip.vehicle
    JOIN routes ON routes.indexr=trip.route
    WHERE vehicles.id_vehicle=$id
    ");
    
}
 ?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Shareholder Details  </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Vehicle profile</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">              
                <?php while ($account = mysqli_fetch_assoc($sql)) { ?>

              <h3 class="profile-username text-center"><?php print $account['plates'];  ?></h3>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Vehicle Make</b> <a class="pull-right"><?php print $account['make'];  ?></a>
                </li>
                <li class="list-group-item">
                  <b>Owner</b> <a class="pull-right"><?php print "OWNER";  ?></a>
               </li>                  
                <li class="list-group-item">
                  <b>Driver</b> <a class="pull-right"><?php print "DRIVER";  ?></a>
                </li>
                <?php } ?>
              </ul>             
            </div>
            <!-- /.box-body -->
          </div>
      </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">              
              <li class="active"><a href="#settings" data-toggle="tab">Trips</a></li>
            </ul>
            <div class="tab-content">

              <div class="active tab-pane" id="settings">
                    <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                      <th>#</th>
                                      <th>Route</th>
                                      <th>Passengers</th>
                                       <th>Total Fare</th>
                                       <th>Water Expense</th>
                                       <th>Commission</th>
                                       <th>Income</th>
                                       <th>Date</th>
                                      <th>View</th>
                                      <th>Delete</th>
                                    </tr>
                                </thead>
                              <tbody>
                                     <?php
                                     $i = 1;
                                     while ($account = mysqli_fetch_assoc($res)) { 
            			                $timestamp = strtotime($account['datecreated']);
                                        list($date, $time) = explode('|', date('d-m-Y|Gi.s', $timestamp));
                                    ?>
            			        <tr>
            		            	<td><?php echo $i; ?></td>
            		            	<td><?php echo $account['name']; ?></td>
            		                <td><?php echo $account['pass']; ?></td>
            		                <td><?php echo $account['tfare']; ?></td>
            		                <td><?php echo $account['water']; ?></td>
            		                <td><?php echo $account['commission']; ?></td>
            		                <td><?php echo $account['income']; ?></td>
            		                <td><?php echo $date; ?></td>
            		                <td>		
            	                    <a href="<?php echo 'trip.php?action=v_view&id='; ?><?php echo $account['indexx']; ?>" ><i class="fa fa-expand"></i></a>
            	                    </td>
            	                    <td>		
            	                    <a onclick="return confirm('The Account will be deleted?')"  href="<?php echo 'bankdelete.php?action=v_view&id='; ?><?php echo $account['ID']; ?>" ><i style="color:red" class="fa fa-times"></i></a>
            	                    </td>
            		            </tr>
            		            <?php $i++; } ?>
                                </tbody>
                            </table>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->

    <!-- Modal -->

  </div>
<?php 
include '../layout/footer.php';
 ?>
