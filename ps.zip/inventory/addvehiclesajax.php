<?php
include '../depend/connectfile.php';
 $date = date("Y-m-d H:i:s");
 $make =  $_POST["make"];
 $plates = $_POST["plates"];
 $owner = $_POST["owner"];
 $driver =  $_POST["driver"];
 $route =  $_POST["route"];
$sql = $conn->query("INSERT INTO vehicles( make, plates, owner, driver, route, date) VALUES ('$make','$plates','$owner','$driver','$route','$date')");

if( $sql) {
       $status = 'ok';
  }
  else{
          $status = 'err';
	
  }
 //echo $status;die; 
?>