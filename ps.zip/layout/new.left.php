<div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-toggle="tooltip" title="Notification" data-placement="bottom" class="dropdown-toggle">
              <i class="fa fa-bell-o"></i>
              <span class="label label-success">2</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">Something</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  
                  <li><!-- start message -->
                    <a href="pendingcon.php">
                      <div class="pull-left">
                        <i class="fa fa-clock-o"></i>
                      </div>
                      <h4>
                        Something                       
                      </h4>
                      <p>Something</p>
                    </a>
                  </li>
                  
                </ul>
              </li>
              <li class="footer"><a href="pendingcon.php">View All</a></li>
            </ul>
          </li>
          
          <li class="dropdown tasks-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-toggle="tooltip" title="Notification" data-placement="bottom" class="dropdown-toggle">
              <i class="fa fa-building"></i>
              <span class="label label-danger">2</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">Something</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  
                  <li>
                    <a href="assignedconctasks.php">
                      <i class="fa fa-building text-aqua"></i> Something
                    </a>
                  </li>
                  
                </ul>
              </li>
              <li class="footer">
                <a href="assignedconctasks.php">View All</a>
              </li>
            </ul>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="../assets/dist/img/avatar5.png" class="user-image" alt="User Image">
              <span class="hidden-xs">2</span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="../assets/dist/img/avatar5.png" class="img-circle" alt="User Image">

                <p>
                 Something
                  <small>Something</small>
                </p>
              </li>
              <!--
              <li class="user-body">
                <div class="row">
                  <div class="col-xs-4 text-center">
                    <a href="#">Followers</a>
                  </div>
                  <div class="col-xs-4 text-center">
                    <a href="#">Sales</a>
                  </div>
                  <div class="col-xs-4 text-center">
                    <a href="#">Friends</a>
                  </div>
                </div>
              </li>-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="profile.php" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="logout.php?logout" class="btn btn-default btn-flat">Logout</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="logout.php?logout"><i class="fa fa-sign-out"></i></a>
          </li>
        </ul>
      </div>