<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Premium Shuttle</b>
    </div>
    <strong>Copyright &copy; <?php echo date('Y'); ?>  All rights
    reserved.
  </footer>
</div>
</body>
</html>