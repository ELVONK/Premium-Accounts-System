<div class="brand clearfix">
<h4 class="pull-left text-white" style="margin:20px 0px 0px 20px"><i class="fa fa-car"></i>&nbsp;Premium Shuttle</h4>
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			
			<li class="ts-account">
				<a href="#"><img src="img/index.png" class="ts-avatar hidden-side" alt=""> Account <i class="fa fa-angle-down hidden-side"></i></a>
				<ul>
			<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>								
			<li><a href="userlist.php"><i class="fa fa-users"></i> Userlist</a>
			</li>
			<li><a href="profile.php"><i class="fa fa-user"></i> &nbsp;Profile</a>
			</li>
			<li><a href="feedback.php"><i class="fa fa-envelope"></i> &nbsp;Feedback</a>
			</li>
			<li><a href="notification.php"><i class="fa fa-bell"></i> &nbsp;Notification <sup style="color:red">*</sup></a>
			</li>
			<li><a href="deleteduser.php"><i class="fa fa-user-times"></i> &nbsp;Deleted Users</a>
			</li>
			<li><a href="download.php"><i class="fa fa-download"></i> &nbsp;Download Users-List</a>
			</li>
			<!--p class="text-center" style="color:#ffffff; margin-top: 100px;">© Microhub Systems</p-->
					<li><a href="change-password.php">Change Password</a></li>
					<li><a href="logout.php">Logout</a></li>
				</ul>
			</li>
		</ul>
	</div>
