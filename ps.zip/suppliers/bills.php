<?php include '../layout/prof.php';?>
<?php include '../layout/header.php';?>
<?php include '../layout/leftbar.php'; ?>
<script src="jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script> 
<script>
function addbill(){
  var vendorName = $("#vendorName").val();  
  var address= $("#address").val();
  var terms= $("#terms").val(); 
  var note= $("#note").val();
  var acc= $("#acc").val();
  var refNo= $("#refNo").val();
  var billdate= $("#billdate").val();
  var duedate= $("#duedate").val();
  var itemName= $("#itemName").val();
  var units= $("#units").val();
  var price= $("#price").val();
  var quantity= $("#quantity").val();
  var total= $("#total").val();
   
      if(vendorName.trim() == '' ){
          alert('Name required.');
          $('#vendorName').focus();
          return false;
      }else{
        $.ajax({
            type:'POST',
            url:'addbills.php',
            data:'contactFrmSubmit=1&vendorName='+vendorName+'&address='+address+'&terms='+terms+'&note='+note+'&acc='+acc+'+&refNo='+refNo+'&billdate='+billdate+'&duedate='+duedate+'&itemName='+itemName+'&units='+units+'&price='+price+'&quantity='+quantity+'&total='+total,
            beforeSend: function () {
                $('.modal-body').css('opacity', '');
                $("#btnSubmit").attr("disabled", true);                
            },
            success:function(msg1){
                if(msg1 == 'ok'){        
$('.statusMsg1').html('<div class="row" style="margin-right: 0px;padding-left: 12px;" ><div class="col-md-10" style="background-color:green;color:#fff;text-align:left;height:30px"><h5>New supplier added</h5></div></div>');
  location.reload();
 }      
     else{
         $(msg1 == 'err').html('<div align="center" class="row" style="margin-right: 0px;padding-left: 12px;" ><div class="col-md-10" style="background-color:green;color:#fff;text-align:left;height:30px"><h5>New supplier added</h5></div></div>');
         // $('.statusMsg1').html('<span style="color:red;"><h5>ocurri贸 alg煤n problema.</h5></span>');
               location.reload();
                }
                $('.submitBtn').removeAttr("disabled");
                $('.modal-body').css('opacity', '');
                $("#btnSubmit").attr("disabled", true);
             }
        });
    }
}
</script>
<div class="wrapper">
  	<div class="content-wrapper">
	    <section class="content-header">
	      <h1>
	        BILLS      
	      </h1>
	      <ol class="breadcrumb">
	        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
	        <li class="active">Supplier</li>
	      </ol>
	    </section>
	    <!-- Main content -->
	    <section class="content">
	        <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <a href=""  data-toggle="modal" data-target="#modal-default">
                      <div class="info-box">
                        <span class="info-box-icon bg-green"><i class="fa fa-user-plus"></i></span>
                        <div class="info-box-content">
                          <span class="info-box-text">New Bill</span>
                          <span class="info-box-number">90</span>
                        </div>
                      </div>
                    </a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="box box-succes">
                        <div class="box-header">
                          <h3 class="box-title">Bills</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                      <th>#</th>
                                      <th>VendorName</th>
                                      <th>Address</th>
                                      <th>Account</th>
                                      <th>Ref No.</th>
                                      <th>Bill date</th>
                                      <th>Due date</th>
                                      <th>Item Name</th>
                                      <th>Units</th>
                                      <th>Price</th>
                                      <th>Quantity</th>
                                      <th>Total Bill</th>
                                      <th>View</th>
                                    
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php	
            		                include '../depend/connectfile.php';
                                    $res=mysqli_query($conn, "SELECT * FROM bills where vendorName!='' order by vendorName asc");
            			            $i = 1;
            			            while ($account = mysqli_fetch_assoc($res)) { ?>
            			            
            			        <tr>
            		            	<td><?php echo $i; ?></td>
            		            	<td><?php echo $account['vendorName']; ?></td>
            		            	<td><?php echo $account['address']; ?></td>
            		                <td><?php echo $account['acc']; ?></td>
            		                 <td><?php echo $account['refNo']; ?></td>
            		                <td><?php echo $account['billdate']; ?></td>
            		                <td><?php echo $account['duedate']; ?></td>
            		                <td><?php echo $account['itemName']; ?></td>
            		                <td><?php echo $account['units']; ?></td>
            		                <td><?php echo $account['price']; ?></td>
            		                <td><?php echo $account['quantity']; ?></td>
            		                <td><?php echo $account['total']; ?></td>
            						<td>		
            	                    <a class="btn btn-success btn-sm" href="<?php echo 'paybill.php?action=v_view&id='; ?><?php echo $account['bill_id']; ?>" >
            	                        <i class="fa fa-money"></i> Pay Bill</a>
            	                    </td>
            	                   
            	                    
            		            </tr>
            		            <?php $i++; } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
	    </section>
	</div>
</div>
<div class="modal fade" id="modal-default">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><b>ADD BILL</b></h5>
            </div>
            <div class="modal-body">
                <form method="POST" name="form" action=""> 
                    <div class="modal-body">                    
                            <div class="row">
                                <div class="col-xs-6">
                                    <label>Vendor Name</label>
                                    <select name="vendorName" id="vendorName" class="form-control" style="height: 35px !important;" required="required">
                                      <option value="">Select Vendor</option>
                                      <?php	
                		                include '../depend/connectfile.php';
                                        $resss=mysqli_query($conn, "SELECT * FROM suppliers where supplierName!='' order by supplierName asc");
                			            while ($accountsup = mysqli_fetch_assoc($resss)) { ?>
                			            <option value="<?php print $accountsup['sindex']; ?>"><?php echo $accountsup['supplierName']; ?></option>
                			             <?php  } ?>
                                      </select>
                                </div>
                                <div class="col-xs-6">
                                  <label>Address</label>
                                  <input type="text" class="form-control" id="address" name="address" >
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-6">
                                  <label>Terms</label><br>
                                  <input class="form-control" id="terms" name="terms" required="required" type="text">
                                </div>
                                 <div class="col-xs-6">
                                  <label>Note</label><br>
                                  <input class="form-control" id="note" name="note" required="required" type="text">
                                </div>
                            </div> 
                            <div class="row">
                                <div class="col-xs-6">
                                  <label>Account</label>
                                  <input class="form-control" id="acc" name="acc" required="required" type="text">
                                </div>
                                <div class="col-xs-6">
                                  <label>Ref No.</label>
                                  <input class="form-control" id="refNo" name="refNo" required="required" type="text">
                                </div>
                                 <div class="col-xs-6">                         
                                  <label>Bill Date</label><br>
                                  <input class="form-control" id="billdate" name="billdate"  type="date"required="required" >
                                </div>
                                <div class="col-xs-6">                         
                                  <label>Due date</label><br>
                                  <input class="form-control"type="date"id="duedate" name="duedate" required="required"  >
                                </div>
                            </div> 
                             <div class="modal-header">
                                <h5 class="modal-title"><b><u>PRODUCTS SUPPLIED</u></b></h5>
                            </div>
                            <div class="row">
                                <div class="col-xs-6">                         
                                  <label>Item Name</label><br>
                                  <input class="form-control" id="itemName" name="itemName"  type="text">
                                </div>
                               <div class="col-xs-6">                         
                                  <label>Units</label><br>
                                  <input class="form-control" id="units" name="units"  type="text"required="required" >
                                </div>
                                <div class="col-xs-6">                         
                                  <label>Price</label><br>
                                  <input class="form-control" id="price" name="price"  type="number"required="required" >
                                </div>
                                <div class="col-xs-6">                         
                                  <label>Quantity</label><br>
                                  <input class="form-control" id="quantity" name="quantity"  type="number"required="required" >
                                </div>
                                <div class="col-xs-6">                         
                                  <label>Total</label><br>
                                  <input class="form-control" id="total" name="total"  min="0" data-ac="(#quantity*#price)"  type="text"required="required" >
                                </div>
                            </div> 
                            <div><p class="statusMsg1"></p></div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" name="sub2" id="sub2" class="btn btn-success pull-right" onclick="addbill()">
                                <span class="glyphicon glyphicon-ok-sign"></span>
                                  Save
                              </button>
                        <button type="button" data-dismiss="modal" aria-label="Close" class="btn btn-warning pull-left">
                          
                            Cancel
                        </button>
                      </div>
                  </form>
              </div>
            </div>
        </div>
    </div>
<script src="jlautocalculate.js"></script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({ timePicker: true, timePickerIncrement: 30, locale: { format: 'MM/DD/YYYY hh:mm A' }})
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass   : 'iradio_minimal-blue'
    })
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass   : 'iradio_minimal-red'
    })
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    })

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  })
</script>
<?php 
include '../layout/scripts.php';
include '../layout/footer.php';
 ?>