<?php 
include '../layout/header.php';
 ?>
  <div class="wrapper">  
    <div class="content-wrapper">
        <section class="content-header">
            <h1><i class="fa fa-money"></i> Pay Supplier</h1>
        </section>
      <section class="content">
        <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#tab_1" data-toggle="tab">Payment Details</a></li>
              <li><a href="#tab_2" data-toggle="tab">Previous Transactions</a></li>              
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">
              	<form>
                <div class=" box-body">           
                <div class="row">
                    <div class="col-md-4">
                        <label>Supplier name</label>
                        <input type="text" class="form-control"  value="" name="suppliername" id="suppliername" required disabled>
                    <input type="hidden" class="form-control"  value="" name="id" id="id" required  >

                    </div>
                    <div class="col-md-4">
                        <label>Amount</label>
                        <input type="text" class="form-control" value=""  name="totalamount" id="totalamount" required disabled>
                    </div>
                    <div class="col-md-4">
                        <label>Ref/ No</label>
                        <input type="text" class="form-control" name="refname" id="refname" required  >
                    </div>
                </div>
                <h4>Payment Info</h4>
                <div class="row">
                    <div class="col-md-4">
                        <label>Mode Of Payment</label>
                        <select class="form-control" id="mode">
                            <option value="BANK">BANK</option>
                            <option value="CASH">CASH</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label>Receipt No</label>
                        <input type="text" class="form-control" name="" id="receiptno" required>
                    </div>
                    <div class="col-md-4">
                        <label>Note</label>
                        <input type="text" class="form-control" name="" id="note" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <label>From Account</label>
                            <select id="account" name="account" class="form-control" style="height: 35px !important;">
                                <option>Select Account</option>
                            </select>
                    </div>
                   <div class="col-md-4">
                        <label>Amount Paid</label>
                        <input type="text" class="form-control" name="amountpaid" id="amountpaid" required>
                    </div>
                    <div class="col-md-4">
                        <label>Balance</label>
                        <input type="text" class="form-control" name="balance" id="balance" required>
                    </div>
                </div>
                <div class="row">
                   
                    <div class="col-md-4">
                        <label>Date Paid</label>
                        <input type="date" class="form-control" name="" id="datepaid" required>
                    </div>
                </div>
                <h4>Paid To (Incase of Cheque: The cheque was written to)</h4>
                <div class="row">
                    <div class="col-md-4">
                        <label> Name</label>
                        <input type="text" class="form-control" name="" id="fullname" required>
                    </div>
                    <div class="col-md-4">
                        <label>Account No</label>
                        <input type="text" class="form-control" name="" id="accno" required>
                    </div>
                </div>
            </div>           
            <div><p class="statusMsg"></p></div> 
            <div class="box-footer">
                <div class="form-group" style="float: right;">
                <div class="col-lg-12">
                  <button class="btn btn-success open1" onclick="submitContactForm()" type="button" style="float: right;"> Save
                    <span class="fa fa-save"></span>
                  </button>
                </div>
              </div>
            </div> 
          </form>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2">
                <table id="example2" class="table table-bordered table-hover">
                    <thead>
                    <tr>
                      <th>Goods/Service</th>
                      <th>Quantity</th>
                      <th>Base Cost</th>
                      <th>Total Cost</th>
                      <th>Total Paid</th>
                      <th>Date Paid</th>
                    </tr>
                    </thead>
                    <tbody>
                        
                    </tbody>
                </table>
              </div>
              
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
    </div> 
      </section>
    </div>
  </div>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({ timePicker: true, timePickerIncrement: 30, locale: { format: 'MM/DD/YYYY hh:mm A' }})
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass   : 'iradio_minimal-blue'
    })
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass   : 'iradio_minimal-red'
    })
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    })

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  })
</script>
<?php 
include '../layout/scripts.php';
include '../layout/footer.php';
 ?>
