<?php
include '../depend/connectfile.php';
 $date = date("Y-m-d H:i:s");
 $supplierName =  $_POST["supplierName"];
 $openingBa = $_POST["openingBa"];
 $dateo = $_POST["dateo"];
 $address =  $_POST["address"];
 $company =  $_POST["company"];
 $fullname = $_POST["fullname"];
 $mobile = $_POST["mobile"];
 $email= $_POST["email"];
 $chequeName = $_POST["chequeName"];
 $accNo = $_POST["accNo"];
 
$sql = $conn->query("INSERT INTO suppliers(supplierName, openingBa, dateo, address, company, fullname, mobile, email, chequeName, accNo, date) VALUES ('$supplierName','$openingBa','$dateo','$address','$company','$fullname','$mobile','$email','$chequeName','$accNo','$date')");

if( $sql) {
    echo   $status = 'ok';
  }
  else{
    echo      $status = 'err';
	
  }
 //echo $status;die; 
?>
