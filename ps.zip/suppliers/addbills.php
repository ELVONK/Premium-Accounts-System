<?php
include '../depend/connectfile.php';
 $date = date("Y-m-d H:i:s");
 $vendorName =  $_POST["vendorName"];
 $address = $_POST["address"];
 $terms = $_POST["terms"];
 $note =  $_POST["note"];
 $acc = $_POST["acc"];
 $refNo = $_POST["refNo"];
 $billdate= $_POST["billdate"];
 $duedate= $_POST["duedate"];
 $itemName = $_POST["itemName"];
 $units = $_POST["units"];
 $price= $_POST["price"];
 $quantity = $_POST["quantity"];
 $total = $_POST["total"];
 
$sql = $conn->query("INSERT INTO bills(vendorName, address, terms, note, acc, refNo, billdate, duedate, itemName, units, price, quantity, total, date) 
VALUES ('$vendorName', '$address', '$terms', '$note', '$acc', '$refNo', '$billdate', '$duedate', '$itemName', '$units', '$price', '$quantity', '$total', '$date')");

if( $sql) {
    echo   $status = 'ok';
  }
  else{
    echo      $status = 'err';
	
  }
 //echo $status;die; 
?>
