<?php include '../layout/prof.php';?>
<?php include '../layout/header.php';?>
<?php include '../layout/leftbar.php'; ?>
<script src="jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script> 
<script>
function addsupplier(){
  var supplierName = $("#supplierName").val();  
  var openingBa= $("#openingBa").val();
  var dateo= $("#dateo").val(); 
  var address= $("#address").val();
  var company= $("#company").val();
  var fullname= $("#fullname").val();
  var mobile= $("#mobile").val();
  var email= $("#email").val();
  var chequeName= $("#chequeName").val();
  var accNo= $("#accNo").val();
   
      if(supplierName.trim() == '' ){
          alert('Name required.');
          $('#supplierName').focus();
          return false;
      }else{
        $.ajax({
            type:'POST',
            url:'addsupplier.php',
            data:'contactFrmSubmit=1&supplierName='+supplierName+'&openingBa='+openingBa+'&dateo='+dateo+'&address='+address+'&company='+company+'&fullname='+fullname+'&mobile='+mobile+'&email='+email+'&chequeName='+chequeName+'&accNo='+accNo,
            beforeSend: function () {
                $('.modal-body').css('opacity', '');
                $("#btnSubmit").attr("disabled", true);                
            },
            success:function(msg1){
                if(msg1 == 'ok'){        
$('.statusMsg1').html('<div class="row" style="margin-right: 0px;padding-left: 12px;" ><div class="col-md-10" style="background-color:green;color:#fff;text-align:left;height:30px"><h5>New supplier added</h5></div></div>');
  location.reload();
 }      
     else{
         $(msg1 == 'err').html('<div align="center" class="row" style="margin-right: 0px;padding-left: 12px;" ><div class="col-md-10" style="background-color:green;color:#fff;text-align:left;height:30px"><h5>New supplier added</h5></div></div>');
         // $('.statusMsg1').html('<span style="color:red;"><h5>ocurri贸 alg煤n problema.</h5></span>');
               location.reload();
                }
                $('.submitBtn').removeAttr("disabled");
                $('.modal-body').css('opacity', '');
                $("#btnSubmit").attr("disabled", true);
             }
        });
    }
}
</script>
<div class="wrapper">
  	<div class="content-wrapper">
	    <section class="content-header">
	      <h1>
	        SUPPLIERS      
	      </h1>
	      <ol class="breadcrumb">
	        <li><a href="../dashboard.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
	        <li class="active">Suppliers</li>
	      </ol>
	    </section>
	    <!-- Main content -->
	    <section class="content">
	        <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <a href=""  data-toggle="modal" data-target="#modal-default">
                      <div class="info-box">
                        <span class="info-box-icon bg-green"><i class="fa fa-user-plus"></i></span>
                        <div class="info-box-content">
                          <span class="info-box-text">New Supplier</span>
                          <span class="info-box-number">90</span>
                        </div>
                      </div>
                    </a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="box box-succes">
                        <div class="box-header">
                          <h3 class="box-title">List of suppliers</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                      <th>#</th>
                                      <th>Supplier Name</th>
                                      <th>Opening Balance</th>
                                      <th>Date</th>
                                      <th>Address</th>
                                      <th>Company</th>
                                      <th>Full Name</th>
                                      <th>Phone No.</th>
                                      <th>Email</th>
                                      <th>Name(Cheque)</th>
                                      <th>Accoun No.</th>
                                      <th>View</th>
                                    
                                    </tr>
                                </thead>
                               <tbody>
                                    <?php	
            		                include '../depend/connectfile.php';
                                    $res=mysqli_query($conn, "SELECT * FROM suppliers where supplierName!='' order by supplierName asc");
            			            $i = 1;
            			            while ($account = mysqli_fetch_assoc($res)) { ?>
            			            
            			        <tr>
            		            	<td><?php echo $i; ?></td>
            		            	<td><?php echo $account['supplierName']; ?></td>
            		            	<td><?php echo $account['openingBa']; ?></td>
            		            	<td><?php echo $account['dateo']; ?></td>
            		            	<td><?php echo $account['address']; ?></td>
            		            	<td><?php echo $account['company']; ?></td>
            		                <td><?php echo $account['fullname']; ?></td>
            		                <td><?php echo $account['mobile']; ?></td>
            		                <td><?php echo $account['email']; ?></td>
            		                <td><?php echo $account['chequeName']; ?></td>
            		                <td><?php echo $account['accNo']; ?></td>
            						<td>		
            	                    <a  href="<?php echo 'editacccounts.php?action=v_view&id='; ?><?php echo $account['supplierName']; ?>" ><i class="fa fa-expand"></i></a>
            	                    </td>
            	                   
            	                    
            		            </tr>
            		            <?php $i++; } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
	    </section>
	</div>
</div>
<div class="modal fade" id="modal-default">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><b>ADD SUPPLIER</b></h4>
            </div>
            <div class="modal-body">
                <form method="POST" name="form" action=""> 
                    <div class="modal-body">                    
                            <div class="row">
                                <div class="col-xs-6">
                                    <label>Supplier Name</label>
                                    <input type="text"class="form-control" name="supplierName" id="supplierName" placeholder="Full Name" required>
                                </div>
                                <div class="col-xs-6">
                                  <label>Opening Balance</label>
                                  <input type="number" class="form-control" id="openingBa" name="openingBa" >
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-6">
                                  <label>Date</label><br>
                                  <input class="form-control" id="dateo" name="dateo" required="required" type="date">
                                </div>
                                <div class="col-xs-6">
                                  <label>Address</label>
                                  <input class="form-control" id="address" name="address" required="required" >
                                </div>
                               
                            </div>
                            <h4 ><b><u>ADDRESS INFO.</u></b></h4>
                            <div class="row">
                                 <div class="col-xs-6">
                                  <label>Company</label>
                                  <input class="form-control" id="company" name="company" required="required" >
                                </div>
                                <div class="col-xs-6">                         
                                  <label>Full Name(contact person)</label><br>
                                  <input class="form-control" id="fullname" name="fullname"  type="text"required="required" >
                                </div>
                                </div>
                            <div class="row">
                                <div class="col-xs-6">                         
                                  <label>Phone NO.</label><br>
                                  <input class="form-control" id="mobile" name="mobile" required="required"data-inputmask='"mask": "9999 999 999"' data-mask  >
                                </div>
                            
                                <div class="col-xs-6">                         
                                  <label>Email</label><br>
                                  <input class="form-control" id="email" name="email"  type="email">
                                </div>
                            </div>
                            <h4 ><b><u>DETAILS ON CHEQUE</u></b></h4>
                            <div class="row">
                               <div class="col-xs-6">                         
                                  <label>Full Name</label><br>
                                  <input class="form-control" id="chequeName" name="chequeName"  type="text"required="required" >
                                </div>
                                <div class="col-xs-6">                         
                                  <label>Account No.</label><br>
                                  <input class="form-control" id="accNo" name="accNo"  type="number"required="required" >
                                </div>
                            </div> 
                            <div><p class="statusMsg1"></p></div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" name="sub2" id="sub2" class="btn btn-success pull-right" onclick="addsupplier()">
                                <span class="glyphicon glyphicon-ok-sign"></span>
                                  Save
                              </button>
                        <button type="button" data-dismiss="modal" aria-label="Close" class="btn btn-warning pull-left">
                          
                            Cancel
                        </button>
                      </div>
                  </form>
              </div>
            </div>
        </div>
    </div>

<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({ timePicker: true, timePickerIncrement: 30, locale: { format: 'MM/DD/YYYY hh:mm A' }})
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass   : 'iradio_minimal-blue'
    })
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass   : 'iradio_minimal-red'
    })
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    })

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  })
</script>
<?php 
include '../layout/scripts.php';
include '../layout/footer.php';
 ?>