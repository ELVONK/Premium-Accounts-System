<?php
include '../depend/connectfile.php';
 $date = date("Y-m-d H:i:s");
 $income_trip =  $_POST["income_trip"];
 $totalexp = $_POST["totalexp"];
 $banked = $_POST["banked"];
 $remarks = $_POST["remarks"];
 
$sql = $conn->query("INSERT INTO accounts(income_trip, totalexp, banked, remarks, datecreated) VALUES('$income_trip','$totalexp','$banked', '$remarks', '$date')");

if( $sql) {
       $status = 'ok';
  }
  else{
          $status = 'err';
	
  }
 //echo $status;die; 
?>
