<?php
include '../depend/connectfile.php';
 $date = date("Y-m-d H:i:s");
 $acc_name =  $_POST["driver_re"];
 $acc_num = $_POST["income"];
 $bank = $_POST["totalre"];
 
$sql = $conn->query("INSERT INTO psvrevenue(driver_re, income, totalre, datecreated) VALUES('$driver_re','$income' ,'$totalre','$date')");

if( $sql) {
       $status = 'ok';
  }
  else{
          $status = 'err';
	
  }
 //echo $status;die; 
?>
