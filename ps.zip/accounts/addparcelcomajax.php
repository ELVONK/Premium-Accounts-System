<?php
include '../depend/connectfile.php';
 $date = date("Y-m-d H:i:s");
 $parcelInc =  $_POST["parcelInc"];
 $commission = $_POST["commission"];
 $banked = $_POST["banked"];
 $remarks = $_POST["remarks"];
 
$sql = $conn->query("INSERT INTO parcelcom(parcelInc, commission, banked, remarks, date) VALUES('$parcelInc','$commission','$banked', '$remarks', '$date')");

if( $sql) {
       $status = 'ok';
  }
  else{
          $status = 'err';
	
  }
 //echo $status;die; 
?>