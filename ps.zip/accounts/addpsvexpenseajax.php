<?php
include '../depend/connectfile.php';
 $date = date("Y-m-d H:i:s");
 $vehicle =  $_POST["vehicle"];
 $route = $_POST["route"];
 $fuel = $_POST["fuel"];
 $oil_service =  $_POST["oil_service"];
 $car_wash = $_POST["car_wash"];
 $lunch = $_POST["lunch"];
 $driver =  $_POST["driver"];
 $council_fee= $_POST["council_fee"];
 $garage= $_POST["garage"];
 $garage1= $_POST["garage1"];
 $garage2= $_POST["garage2"];
 $garage3= $_POST["garage3"];
  $others= $_POST["others"];
 $total_expense= $_POST["total_expense"];
 
$sql = $conn->query("INSERT INTO psvexpense(vehicle, route, fuel, oil_service, car_wash, lunch, driver,council_fee,garage,garage1,garage2,garage3,others,total_expense,date) VALUES ('$vehicle','$route','$fuel','$oil_service','$car_wash','$lunch','$driver','$council_fee','$garage','$garage1','$garage2','$garage3','$others','$total_expense','$date')");


if( $sql) {
       $status = 'ok';
  }
  else{
          $status = 'err';
	
  }
 //echo $status;die; 
?>
