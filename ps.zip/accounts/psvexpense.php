<?php include '../layout/prof.php';?>
<?php include '../layout/header.php';?>
<?php include '../layout/leftbar.php'; ?>
 <script src="jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script> 
<script>
function addpsvexpense(){
var vehicle = $("#vehicle").val(); 
var route = $("#route").val(); 
var fuel = $("#fuel").val(); 
var oil_service = $("#oil_service").val(); 
var car_wash = $("#car_wash").val(); 
var lunch = $("#lunch").val(); 
var driver = $("#driver").val(); 
var council_fee = $("#council_fee").val(); 
var garage = $("#garage").val();
var garage1 = $("#garage1").val();
var garage2 = $("#garage2").val();
var garage3 = $("#garage3").val();
var others = $("#others").val();
var total_expense = $("#total_expense").val();

      if(vehicle.trim() == '' ){
          alert('vehicle required.');
          $('#vehicle').focus();
          return false;
      }else{
        $.ajax({
            type:'POST',
            url:'addpsvexpenseajax.php',
            data:'contactFrmSubmit=1&vehicle='+vehicle+'&route='+route+'&fuel='+fuel+'&oil_service='+oil_service+'&car_wash='+car_wash+'&lunch='+lunch+'&driver='+driver+'&council_fee='+council_fee+'&garage='+garage+'&garage1='+garage1+'&garage2='+garage2+'&garage3='+garage3+'&others='+others+'&total_expense='+total_expense,
            beforeSend: function () {
                $('.modal-body').css('opacity', '');
                $("#btnSubmit").attr("disabled", true);                
            },
            success:function(msg1){
                if(msg1 == 'ok'){        
$('.statusMsg1').html('<div class="row" style="margin-right: 0px;padding-left: 12px;" ><div class="col-md-10" style="background-color:green;color:#fff;text-align:left;height:30px"><h5>Trip Saved</h5></div></div>');
  location.reload();
 }      
     else{
$(msg1 == 'err').html('<div align="center" class="row" style="margin-right: 0px;padding-left: 12px;" ><div class="col-md-10" style="background-color:green;color:#fff;text-align:left;height:30px"><h5>Trip Saved</h5></div></div>');
         // $('.statusMsg1').html('<span style="color:red;"><h5>ocurri贸 alg煤n problema.</h5></span>');
               location.reload();
                }
                $('.submitBtn').removeAttr("disabled");
                $('.modal-body').css('opacity', '');
                $("#btnSubmit").attr("disabled", true);
             }
        });
    }
}
</script>
<div class="wrapper">
  	<div class="content-wrapper">
	    <section class="content-header">
	      <h1>
	        PSV Expense        
	      </h1>
	      <ol class="breadcrumb">
	        <li><a href="../dashboard.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
	        <li class="active">Expenses</li>
	      </ol>
	    </section>
	    <!-- Main content -->
	    <section class="content">
	        <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <a href=""  data-toggle="modal" data-target="#modal-default">
                      <div class="info-box">
                        <span class="info-box-icon bg-aqua"><i class="fa fa-bus"></i></span>
                        <div class="info-box-content">
                          <span class="info-box-text">Add Expense</span>
                          <span class="info-box-number">90</span>
                        </div>
                      </div>
                    </a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="box box-succes">
                        <div class="box-header">
                          <h3 class="box-title">PSV Expense list</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                      <th>#</th>
                                      <th>vehicle</th>
                                      <th>route</th>
                                      <th>fuel</th>
                                      <th>oil/ser</th>
                                      <th>carwash</th>
                                      <th>lunch</th>
                                      <th>driver</th>
                                      <th>council</th>
                                      <th>garage</th>
                                      <th>garage1</th>
                                      <th>garage2</th>
                                      <th>garage3</th>
                                      <th>others</th>
                                      <th>Total</th>
                                      <th>Date</th>
                                      <th>View</th>
                                      
                                    </tr>
                                </thead>
                               <tbody>
                                     <?php	
            		                include '../depend/connectfile.php';
                                    $ress=mysqli_query($conn, "SELECT vehicles.plates, routes.name, psvexpense.fuel, psvexpense.oil_service, psvexpense.car_wash, psvexpense.lunch, psvexpense.driver, psvexpense.council_fee, psvexpense.garage,psvexpense.garage1,psvexpense.garage2,psvexpense.garage3, psvexpense.others, psvexpense.total_expense, psvexpense.date 
FROM psvexpense 
JOIN vehicles ON vehicles.id_vehicle=psvexpense.vehicle
JOIN routes ON routes.indexr=psvexpense.route");
            			            $i = 1;
            			            while ($account = mysqli_fetch_assoc($ress)) { 
            			            $timestamp = strtotime($account['date']);
                                         list($date, $time) = explode('|', date('d-m-Y|Gi.s', $timestamp));
                                         ?>
            			        <tr>
            		            	<td><?php echo $i; ?></td>
            		            	<td><?php echo $account['plates']; ?></td>
            		            	<td><?php echo $account['name']; ?></td>
            		                <td><?php echo $account['fuel']; ?></td>
            		                <td><?php echo $account['oil_service']; ?></td>
            		            	<td><?php echo $account['car_wash']; ?></td>
            		                <td><?php echo $account['lunch']; ?></td>
            		                <td><?php echo $account['driver']; ?></td>
            		            	<td><?php echo $account['council_fee']; ?></td>
            		                <td><?php echo $account['garage']; ?></td>
            		                <td><?php echo $account['garage1']; ?></td>
            		                <td><?php echo $account['garage2']; ?></td>
            		                <td><?php echo $account['garage3']; ?></td>
            		                <td><?php echo $account['others']; ?></td>
            		                 <td><?php echo $account['total_expense']; ?></td>
            		                 <td><?php echo $date; ?></td>
            						<td>		
            	                    <a  href="<?php echo 'editacccounts.php?action=v_view&id='; ?><?php echo $account['indexx']; ?>" ><i class="fa fa-expand"></i></a>
            	                    </td>
            	                    
            		            </tr>
            		            <?php $i++; }  ?>
                                </tbody>
                                </table>
                        </div>
                    </div>
                </div>
            </div>
	    </section>
	</div>
</div>
<div class="modal fade" id="modal-default">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">Add PSV Expense</h4>
            </div>
            <div class="modal-body">
                <form method="POST" name="form" action=""> 
                    <div class="modal-body">                    
                           
                            <div class="row">
                                <div class="col-xs-6">
                                  <label>Vehicle</label>
                                  <select id="vehicle" name="vehicle" class="form-control" style="height: 35px !important;">
                                      <option value="">Select Vehicle</option>
                                      <?php	
            		                include '../depend/connectfile.php';
                                    $ress=mysqli_query($conn, "SELECT * FROM vehicles where plates!='' order by plates asc");
            			            while ($accounts = mysqli_fetch_assoc($ress)) { ?>
            			            <option value="<?php print $accounts['id_vehicle']; ?>"><?php echo $accounts['plates']; ?></option>
            			             <?php  } ?>
                                  </select>
                                </div>
                                 <div class="col-xs-6">
                                  <label>route</label>
                                  <select id="route" name="route" class="form-control" style="height: 35px !important;" required="required">
                                      <option value="">Select route</option>
                                      <?php	
            		                include '../depend/connectfile.php';
                                    $ress=mysqli_query($conn, "SELECT * FROM routes where name!='' order by name asc");
            			            while ($accounts = mysqli_fetch_assoc($ress)) { ?>
            			            <option value="<?php print $accounts['indexr']; ?>"><?php echo $accounts['name']; ?></option>
            			             <?php  } ?>
                                  </select>
                                </div>
                                 
                                
                              
                            </div>
                            <div class="row">
                               
                                <div class="col-xs-6">                         
                                  <label>Fuel</label><br>
                                  
                                   <input class="form-control" type="number" id="fuel" name="fuel"  required="required">
                                </div>
                                <div class="col-xs-6">                         
                                  <label>Oil/service</label><br>
                                  
                                   <input class="form-control" type="number" id="oil_service" name="oil_service"  required="required">
                                    <input class="form-control"  type="hidden" min="0" data-ac="(#fuel+#oil_service)" id="calc" name="calc" >
                                </div>
                                <div class="col-xs-6">                         
                                  <label>Car wash</label><br>
                                  
                                   <input class="form-control" type="number" id="car_wash" name="car_wash"  required="required">
                                  
                                </div>
                                <div class="col-xs-6">                         
                                  <label>Lunch</label><br>
                                  
                                   <input class="form-control" type="number" id="lunch" name="lunch"  required="required">
                                    
                                </div>
                                <div class="col-xs-6">                         
                                  <label>Driver</label><br>
                                  
                                   <input class="form-control" type="number" id="driver" name="driver"  required="required">
                                    <input class="form-control"  type="hidden" min="0" data-ac="(#car_wash+#lunch)" id="calc2" name="calc2" >
                                </div>
                                <div class="col-xs-6">                         
                                  <label>Council Fee</label><br>
                                  
                                   <input class="form-control" type="number" id="council_fee" name="council_fee"  required="required">
                                    <input class="form-control"  type="hidden" min="0" data-ac="(#calc+#driver)" id="calc1" name="calc1" >
                                </div>
                                <div class="col-xs-6">                         
                                  <label>Garage</label><br>
                                  
                                   <input class="form-control" type="number" id="garage" name="garage"  required="required">
                                    <input class="form-control"  type="hidden" min="0" data-ac="(#calc2+#council_fee)" id="calc3" name="calc3" >
                                </div>
                                 <div class="col-xs-6">                         
                                  <label>Garage1</label><br>
                                  
                                   <input class="form-control" type="number" id="garage1" name="garage1"  required="required">
                                    
                                </div>
                                 <div class="col-xs-6">                         
                                  <label>Garage2</label><br>
                                  
                                   <input class="form-control" type="number" id="garage2" name="garage2"  required="required">
                                     <input class="form-control"  type="hidden" min="0" data-ac="(#garage1+#garage2)" id="cal" name="cal" >
                                </div>
                                 <div class="col-xs-6">                         
                                  <label>Garage3</label><br>
                                  
                                   <input class="form-control" type="number" id="garage3" name="garage3"  required="required">
                                    <input class="form-control"  type="hidden" min="0" data-ac="(#cal+#garage3)" id="cal1" name="cal1" >
                                    <input class="form-control"  type="hidden" min="0" data-ac="(#calc1+#garage)" id="calc4" name="calc4" >
                                </div>
                                
                                <div class="col-xs-6">                         
                                  <label>Others(specify)</label><br>
                                  <input class="form-control"  type="number" min="0" id="others" name="others" onblur="calculate()" required="required" >
                                   <input class="form-control"  type="hidden" min="0" data-ac="(#cal1+#calc4)" id="cal2" name="cal2" >
                                    <input class="form-control"  type="hidden" min="0" data-ac="(#calc3+#others)" id="calc5" name="calc5" >
                                 
                                </div>
                                <div class="col-xs-6">                         
                                  <label>Total Expenses</label><br>
                                  <input class="form-control"  type="number" min="0" data-ac="(#cal2+#calc5)" id="total_expense" name="total_expense" >
                                  
                                </div>
                            </div> 
                           <div><p class="statusMsg1"></p></div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" name="sub2" id="sub2" class="btn btn-success pull-right"  onclick="addpsvexpense()">
                                <span class="glyphicon glyphicon-ok-sign"></span>
                                  Save
                              </button>
                        <button type="button" data-dismiss="modal" aria-label="Close" class="btn btn-warning pull-left">
                          
                            Cancel
                        </button>
                      </div>
                  </form>
              </div>
            </div>
        </div>
    </div>

<script src="jlautocalculate.js"></script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({ timePicker: true, timePickerIncrement: 30, locale: { format: 'MM/DD/YYYY hh:mm A' }})
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass   : 'iradio_minimal-blue'
    })
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass   : 'iradio_minimal-red'
    })
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    })

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  })
</script>
<?php 
include '../layout/scripts.php';
include '../layout/footer.php';
 ?>