<?php include '../layout/prof.php';?>
<?php include '../layout/header.php';?>
<?php include '../layout/leftbar.php'; ?>
<script src="jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script> 
<script>
function addstaff(){
  var u_fname = $("#u_fname").val();  
  var u_address= $("#u_address").val();
  var idnumber= $("#idnumber").val(); 
  var u_mobile= $("#u_mobile").val();
  var u_email= $("#u_email").val();
  var gross= $("#gross").val();
  var designation= $("#designation").val();
  
      if(u_fname.trim() == '' ){
          alert('Name required.');
          $('#u_fname').focus();
          return false;
      }else{
        $.ajax({
            type:'POST',
            url:'addstaff.php',
            data:'contactFrmSubmit=1&u_fname='+u_fname+'&u_address='+u_address+'&idnumber='+idnumber+'&u_mobile='+u_mobile+'&u_email='+u_email+'&gross='+gross+'&designation='+designation,
            beforeSend: function () {
                $('.modal-body').css('opacity', '');
                $("#btnSubmit").attr("disabled", true);                
            },
            success:function(msg1){
                if(msg1 == 'ok'){        
$('.statusMsg1').html('<div class="row" style="margin-right: 0px;padding-left: 12px;" ><div class="col-md-10" style="background-color:green;color:#fff;text-align:left;height:30px"><h5>User Saved</h5></div></div>');
  location.reload();
 }      
     else{
         $(msg1 == 'err').html('<div align="center" class="row" style="margin-right: 0px;padding-left: 12px;" ><div class="col-md-10" style="background-color:green;color:#fff;text-align:left;height:30px"><h5>User Saved</h5></div></div>');
         // $('.statusMsg1').html('<span style="color:red;"><h5>ocurri贸 alg煤n problema.</h5></span>');
               location.reload();
                }
                $('.submitBtn').removeAttr("disabled");
                $('.modal-body').css('opacity', '');
                $("#btnSubmit").attr("disabled", true);
             }
        });
    }
}
</script>
<div class="wrapper">
  	<div class="content-wrapper">
	    <section class="content-header">
	      <h1>
	        EMPLOYEES REGISTER       
	      </h1>
	      <ol class="breadcrumb">
	        <li><a href="../dashboard.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
	        <li class="active">Employee</li>
	      </ol>
	    </section>
	    <!-- Main content -->
	    <section class="content">
	        <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <a href=""  data-toggle="modal" data-target="#modal-default">
                      <div class="info-box">
                        <span class="info-box-icon bg-green"><i class="fa fa-user-plus"></i></span>
                        <div class="info-box-content">
                          <span class="info-box-text">Add Employee</span>
                          <span class="info-box-number">90</span>
                        </div>
                      </div>
                    </a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="box box-succes">
                        <div class="box-header">
                          <h3 class="box-title">List of Employees</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                      <th>#</th>
                                      <th>Full Name</th>
                                      <th>ID/Driving Licence</th>
                                      <th>Telephone</th>
                                      <th>Email</th>
                                      <th>Address</th>
                                      <th>Gross Salary</th>
                                      <th>Designation</th>
                                      <th>View</th>
                                      <th>Salary</th>
                                      
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php	
            		                include '../depend/connectfile.php';
                                    $res=mysqli_query($conn, "SELECT * FROM staffs where full_name!='' order by full_name asc");
            			            $i = 1;
            			            while ($account = mysqli_fetch_assoc($res)) { ?>
            			            
            			        <tr>
            		            	<td><?php echo $i; ?></td>
            		            	<td><?php echo $account['full_name']; ?></td>
            		            	<td><?php echo $account['id_number']; ?></td>
            		            	<td><?php echo $account['phone_no']; ?></td>
            		            	<td><?php echo $account['email']; ?></td>
            		                <td><?php echo $account['address']; ?></td>
            		                <td><?php echo $account['gross']; ?></td>
            		                 <td><?php echo $account['designation']; ?></td>
            						<td>		
            	                    <a  href="<?php echo 'editacccounts.php?action=v_view&id='; ?><?php echo $account['staff_id']; ?>" ><i class="fa fa-expand"></i></a>
            	                    </td>
            	                    <td>		
            	                    <a class="btn btn-success btn-sm" href="<?php echo 'staffpay.php?action=v_view&id='; ?><?php echo $account['staff_id']; ?>" ><i class="fa fa-money"></i> Salary</a>
            	                    </td>
            	                    
            		            </tr>
            		            <?php $i++; } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
	    </section>
	</div>
</div>
<div class="modal fade" id="modal-default">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">Add Driver</h4>
            </div>
            <div class="modal-body">
                <form method="POST" name="form" action=""> 
                    <div class="modal-body">                    
                            <div class="row">
                                <div class="col-xs-6">
                                    <label>Full Name</label>
                                    <input type="text"class="form-control" name="u_fname" id="u_fname" placeholder="Full Name" required>
                                </div>
                                <div class="col-xs-6">
                                  <label>Address</label>
                                  <input type="text" class="form-control" id="u_address" name="u_address" >
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-6">
                                  <label>ID Number</label><br>
                                  <input class="form-control" id="idnumber" name="idnumber" required="required" type="email">
                                </div>
                                <div class="col-xs-6">
                                  <label>Telephone</label>
                                  <input class="form-control" id="u_mobile" name="u_mobile" required="required" data-inputmask='"mask": "9999 999 999"' data-mask>
                                </div>
                            </div> 
                            <div class="row">
                                <div class="col-xs-6">                         
                                  <label>Email</label><br>
                                  <input class="form-control" id="u_email" name="u_email"  type="email">
                                </div>
                                 <div class="col-xs-6">                         
                                  <label>Gross Salary</label><br>
                                  <input class="form-control" id="gross" name="gross"  type="number"required="required" >
                                </div>
                                <div class="col-xs-6">                         
                                  <label>Designation</label><br>
                                  <input class="form-control" id="designation" name="designation"  type="text"required="required" >
                                </div>
                            </div> 
                            <div><p class="statusMsg1"></p></div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" name="sub2" id="sub2" class="btn btn-success pull-right" onclick="addstaff()">
                                <span class="glyphicon glyphicon-ok-sign"></span>
                                  Save
                              </button>
                        <button type="button" data-dismiss="modal" aria-label="Close" class="btn btn-warning pull-left">
                          
                            Cancel
                        </button>
                      </div>
                  </form>
              </div>
            </div>
        </div>
    </div>

<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({ timePicker: true, timePickerIncrement: 30, locale: { format: 'MM/DD/YYYY hh:mm A' }})
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass   : 'iradio_minimal-blue'
    })
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass   : 'iradio_minimal-red'
    })
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    })

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  })
</script>
<?php 
include '../layout/scripts.php';
include '../layout/footer.php';
 ?>