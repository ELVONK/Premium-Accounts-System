<?php 
include '../layout/header.php';
include '../depend/connectfile.php';
if($_GET["action"] == "v_view"){
     $id = $_GET["id"];

    $sql = $conn->query("SELECT * FROM drivers WHERE indexx='$id'");
    $sql2 = $conn->query("SELECT * FROM drivers WHERE indexx='$id'");
    while ($data = mysqli_fetch_assoc($sql2)) {
        $idnumber = $data['id_number'];
        $gross = $data['gross'];
    }
    
    $advance = $conn->query("SELECT * FROM advancepay WHERE name='$id' and idNO='$idnumber' and (advance != paid)");
    while ($advanceq = mysqli_fetch_assoc($advance)) {
        $advanceamnt = $advanceq['advance'];
        $advanceid = $advanceq['adindex'];
    }
    $loan = $conn->query("SELECT * FROM  loans WHERE name='$id' and idNO='$idnumber' and (loanamnt != amntpaid)");
    while ($loanq = mysqli_fetch_assoc($loan)) {
        $loanamnt = $loanq['deductable'];
        $loanid = $loanq['lindex'];
    }
}?>
<script src="jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script> 
<script>
function addstaffpay(){
  var name = $("#name").val();  
  var idno= $("#idno").val();
  var gross= $("#gross").val();
  var advance = $("#advance").val();  
  var loan= $("#loan").val();
  var net= $("#net").val();
  var remarks= $("#remarks").val();adid
  var loanid= $("#lid").val();
  var advanceid= $("#adid").val();
      
      if(name.trim() == '' ){
          alert('Name required.');
          $('#name').focus();
          return false;
      }else{
        $.ajax({
            type:'POST',
            url:'addstaffpayajax.php',
            data:'contactFrmSubmit=1&name='+name+'&idno='+idno+'&gross='+gross+'&advance='+advance+'&loan='+loan+'&net='+net+'&remarks='+remarks+'&loanid='+loanid+'&advanceid='+advanceid,
            beforeSend: function () {
                $('.modal-body').css('opacity', '');
                $("#btnSubmit").attr("disabled", true);                
            },
            success:function(msg1){
                if(msg1 == 'ok'){        
$('.statusMsg1').html('<div class="row" style="margin-right: 0px;padding-left: 12px;" ><div class="col-md-10" style="background-color:green;color:#fff;text-align:left;height:30px"><h5>User Saved</h5></div></div>');
  location.reload();
 }      
     else{
         $(msg1 == 'err').html('<div align="center" class="row" style="margin-right: 0px;padding-left: 12px;" ><div class="col-md-10" style="background-color:green;color:#fff;text-align:left;height:30px"><h5>User Saved</h5></div></div>');
         // $('.statusMsg1').html('<span style="color:red;"><h5>ocurri贸 alg煤n problema.</h5></span>');
               location.reload();
                }
                $('.submitBtn').removeAttr("disabled");
                $('.modal-body').css('opacity', '');
                $("#btnSubmit").attr("disabled", true);
             }
        });
    }
}
</script>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Staf Salary Payment</h1>
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Staff Salary</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">              
                <?php while ($account = mysqli_fetch_assoc($sql)) { ?>

              <h3 class="profile-username text-center"><?php print $account['driver_name'];  ?></h3>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Id Number</b> <a class="pull-right"><?php print $account['id_number'];  ?></a>
                </li>
                <li class="list-group-item">
                  <b>Driving License</b> <a class="pull-right"><?php print $account['driving_license'];  ?></a>
                </li>
                <li class="list-group-item">
                  <b>Telephone</b> <a class="pull-right"><?php print $account['tel'];  ?></a>
               </li>                  
                <li class="list-group-item">
                  <b>Email</b> <a class="pull-right"><?php print $account['email'];  ?></a>
                </li>
                <?php } ?>
              </ul>             
            </div>
            <!-- /.box-body -->
          </div>
      </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">              
              <li class="active"><a href="#settings" data-toggle="tab">Pay Salary</a></li>
              <li><a href="#loans" data-toggle="tab">Loans</a></li>
            </ul>
            <input type="hidden" class="form-control" name="name" id="name" value="<?php echo $id; ?>">
            <input type="hidden" class="form-control" id="idno" name="idno"  value="<?php echo $idnumber; ?>">
            <input type="hidden" class="form-control" id="lid" name="lid"  value="<?php echo $loanid; ?>">
            <input type="hidden" class="form-control" id="adid" name="adid"  value="<?php echo $advanceid; ?>">
            <div class="tab-content">
              <div class="active tab-pane" id="settings">
                            <div class="row">
                                <div class="col-xs-6">                         
                                  <label>Gross Salary</label><br>
                                  <input class="form-control" id="gross" name="gross" required="required" type="number" value="<?php echo $gross; ?>" disabled>
                                </div>
                                <div class="col-xs-6">                         
                                  <label>Advance Pay</label><br>
                                  <input class="form-control" id="advance" name="advance" required="required" type="number" value="<?php echo $advanceamnt; ?>" disabled>
                                </div>
                            </div> 
                            <div class="row">
                                <div class="col-xs-6">
                                  <label>Loan Deduction</label>
                                  <input class="form-control" id="loan" name="loan" required="required" value="<?php echo $loanamnt; ?>" <?php if($loanamnt==''){ echo "disabled";} ?>>
                                   <input class="form-control"  type="hidden" min="0" data-ac="(#advance+#loan)" id="calc" name="calc" >
                                </div>
                                
                                <div class="col-xs-6">                         
                                  <label>Net Salary</label><br>
                                  <input class="form-control" id="net" name="net"  data-ac="(#gross-#calc)" type="number">
                                </div>
                                 <div class="col-xs-6">                         
                                  <label>Remarks</label><br>
                                  <input class="form-control" id="remarks" name="remarks" type="text">
                                </div>
                            </div> 
                            <div><p class="statusMsg1"></p></div>
                    <div class="box-footer">
                        <button type="button" name="sub2" id="sub2" class="btn btn-success pull-right" onclick="addstaffpay()">
                                <span class="glyphicon glyphicon-ok-sign"></span>
                                  Save
                              </button>
                    </div>
              </div>
              <div class="tab-pane" id="loans">
                    <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                      <th>#</th>
                                      <th>Make</th>
                                      <th>Plates</th>
                                      <th>Driver</th>
                                      <th>View</th>
                                      <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                     
                                </tbody>
                            </table>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->

    <!-- Modal -->

  </div>
  <script src="jlautocalculate.js"></script>
<?php 
include '../layout/scripts.php';
include '../layout/footer.php';
 ?>
