<?php
include '../depend/connectfile.php';
 $date = date("Y-m-d H:i:s");
 $u_fname =  $_POST["u_fname"];
 $u_address = $_POST["u_address"];
 $idnumber = $_POST["idnumber"];
 $dl_name =  $_POST["dl_name"];
 $u_mobile = $_POST["u_mobile"];
 $u_email = $_POST["u_email"];
 $gross = $_POST["gross"];
 
$sql = $conn->query("INSERT INTO drivers( driver_name, id_number, driving_license, tel, email, address,gross, date) VALUES ('$u_fname','$idnumber','$dl_name','$u_mobile','$u_email','$u_address','$gross','$date')");

if( $sql) {
       $status = 'ok';
  }
  else{
          $status = 'err';
	
  }
 //echo $status;die; 
?>
