<?php
include '../depend/connectfile.php';
 $date = date("Y-m-d H:i:s");
 $name =  $_POST["name"];
 $idNo = $_POST["idNo"];
 $loanamnt = $_POST["loanamnt"];
 $repayPeriod = $_POST["repayPeriod"];
 $deductable =  $_POST["deductable"];
 $remarks = $_POST["remarks"];
 $zero = "0";
$sql = $conn->query("INSERT INTO loans(name, idNo, loanamnt, repayPeriod, deductable, remarks, amntpaid, dategranted) VALUES ('$name', '$idNo', '$loanamnt', '$repayPeriod', '$deductable', '$remarks', '$zero', '$date')");

if( $sql) {
    echo   $status = 'ok';
  }
  else{
    echo $status = 'err';
	
  }
 //echo $status;die; 
?>