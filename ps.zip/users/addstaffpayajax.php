<?php
include '../depend/connectfile.php';
 $date = date("Y-m-d H:i:s");
 $name =  $_POST["name"];
 $idno = $_POST["idno"];
 $gross = $_POST["gross"];
 $advance =  $_POST["advance"];
 $loan = $_POST["loan"];
 $net = $_POST["net"];
 $remarks = $_POST["remarks"];
 $loanid = $_POST["loanid"];
 $advanceid = $_POST["advanceid"];
 
$sql = $conn->query("INSERT INTO staffpayroll( name, idno, gross, advance, loan, net, remarks, date) VALUES ('$name','$idno','$gross','$advance','$loan','$net','$remarks','$date')");

$sql2 = $conn->query("UPDATE loans SET amntpaid=amntpaid+'$loan'  WHERE lindex=$loanid and idNo= $idno");

$sql3 = $conn->query("UPDATE advancepay SET paid=paid+'$advance' WHERE adindex=$advanceid and idNo=$idno");

if( $sql) {
       $status = 'ok';
  }
  else{
          $status = 'err';
	
  }
 //echo $status;die; 
?>
