<?php include '../layout/prof.php';?>
<?php include '../layout/header.php';?>
<?php include '../layout/leftbar.php'; ?>
<script src="jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script> 
<script>
function addstaffpay(){
  var name = $("#name").val();  
  var idno= $("#idno").val();
  var gross= $("#gross").val();
  var advance = $("#advance").val();  
  var loan= $("#loan").val();
  var net= $("#net").val();
  var remarks= $("#remarks").val();
      
      if(name.trim() == '' ){
          alert('Name required.');
          $('#name').focus();
          return false;
      }else{
        $.ajax({
            type:'POST',
            url:'addstaffpayajax.php',
            data:'contactFrmSubmit=1&name='+name+'&idno='+idno+'&gross='+gross+'&advance='+advance+'&loan='+loan+'&net='+net+'&remarks='+remarks,
            beforeSend: function () {
                $('.modal-body').css('opacity', '');
                $("#btnSubmit").attr("disabled", true);                
            },
            success:function(msg1){
                if(msg1 == 'ok'){        
$('.statusMsg1').html('<div class="row" style="margin-right: 0px;padding-left: 12px;" ><div class="col-md-10" style="background-color:green;color:#fff;text-align:left;height:30px"><h5>User Saved</h5></div></div>');
  location.reload();
 }      
     else{
         $(msg1 == 'err').html('<div align="center" class="row" style="margin-right: 0px;padding-left: 12px;" ><div class="col-md-10" style="background-color:green;color:#fff;text-align:left;height:30px"><h5>User Saved</h5></div></div>');
         // $('.statusMsg1').html('<span style="color:red;"><h5>ocurri贸 alg煤n problema.</h5></span>');
               location.reload();
                }
                $('.submitBtn').removeAttr("disabled");
                $('.modal-body').css('opacity', '');
                $("#btnSubmit").attr("disabled", true);
             }
        });
    }
}
</script>
<div class="wrapper">
  	<div class="content-wrapper">
	    <section class="content-header">
	      <h1>
	        Staff and Driver  Payroll        
	      </h1>
	      <ol class="breadcrumb">
	        <li><a href="../dashboard.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
	        <li class="active">Staff</li>
	      </ol>
	    </section>
	    <!-- Main content -->
	    <section class="content">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="box box-succes">
                        <div class="box-header">
                          <h3 class="box-title">PAYROLL</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                      <th>#</th>
                                      <th>Name</th>
                                      <th>ID</th>
                                      <th>Gross Salary</th>
                                      <th>Advance</th>
                                      <th>Loan Deduction</th>
                                      <th>Net Salary</th>
                                      <th>Remarks</th>
                                      <th>Date</th>
                                      <th>View</th>
                                     
                                    </tr>
                                </thead>
                               <tbody>
                                    <?php	
            		                include '../depend/connectfile.php';
                                    $res=mysqli_query($conn, "SELECT * FROM staffpayroll where name!='' order by name asc");
            			               $i = 1;
            			            while ($account = mysqli_fetch_assoc($res)) { 
            			            $timestamp = strtotime($account['date']);
                                         list($date, $time) = explode('|', date('d-m-Y|Gi.s', $timestamp));
                                         ?>
            			            
            			        <tr>
            		            	<td><?php echo $i; ?></td>
            		            	<td><?php echo $account['name']; ?></td>
            		            	<td><?php echo $account['idno']; ?></td>
            		            	<td><?php echo $account['gross']; ?></td>
            		            	<td><?php echo $account['advance']; ?></td>
            		            	<td><?php echo $account['loan']; ?></td>
            		                <td><?php echo $account['net']; ?></td>
            		                <td><?php echo $account['remarks']; ?></td>
            		                <td><?php echo $date; ?></td>
            						<td>		
            	                    <a  href="<?php echo 'editacccounts.php?action=v_view&id='; ?><?php echo $account['pindex']; ?>" ><i class="fa fa-expand"></i></a>
            	                    </td>
            	                   
            		            </tr>
            		            <?php $i++; } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
	    </section>
	</div>
</div>
<div class="modal fade" id="modal-default">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">ADD STAFF</h4>
            </div>
            <div class="modal-body">
                <form method="POST" name="form" action=""> 
                    <div class="modal-body">                    
                            <div class="row">
                                <div class="col-xs-6">
                                    <label>Name</label>
                                    <input type="text"class="form-control" name="name" id="name" placeholder="Full Name" required>
                                </div>
                                <div class="col-xs-6">
                                  <label>ID Number</label>
                                  <input type="text" class="form-control" id="idno" name="idno" >
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-6">                         
                                  <label>Gross Salary</label><br>
                                  <input class="form-control" id="gross" name="gross" required="required" type="number">
                                </div>
                                <div class="col-xs-6">                         
                                  <label>Advance Pay</label><br>
                                  <input class="form-control" id="advance" name="advance" required="required" type="number">
                                </div>
                            </div> 
                            <div class="row">
                                <div class="col-xs-6">
                                  <label>Loan Deduction</label>
                                  <input class="form-control" id="loan" name="loan" required="required" >
                                   <input class="form-control"  type="hidden" min="0" data-ac="(#advance+#loan)" id="calc" name="calc" >
                                </div>
                                
                                <div class="col-xs-6">                         
                                  <label>Net Salary</label><br>
                                  <input class="form-control" id="net" name="net"  data-ac="(#gross-#calc)" type="number">
                                </div>
                                 <div class="col-xs-6">                         
                                  <label>Remarks</label><br>
                                  <input class="form-control" id="remarks" name="remarks" type="text">
                                </div>
                            </div> 
                            <div><p class="statusMsg1"></p></div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" name="sub2" id="sub2" class="btn btn-success pull-right" onclick="addstaffpay()">
                                <span class="glyphicon glyphicon-ok-sign"></span>
                                  Save
                              </button>
                        <button type="button" data-dismiss="modal" aria-label="Close" class="btn btn-warning pull-left">
                          
                            Cancel
                        </button>
                      </div>
                  </form>
              </div>
            </div>
        </div>
    </div>
<script src="jlautocalculate.js"></script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({ timePicker: true, timePickerIncrement: 30, locale: { format: 'MM/DD/YYYY hh:mm A' }})
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass   : 'iradio_minimal-blue'
    })
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass   : 'iradio_minimal-red'
    })
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    })

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  })
</script>
<?php 
include '../layout/scripts.php';
include '../layout/footer.php';
 ?>