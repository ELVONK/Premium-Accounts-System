<?php
include '../depend/connectfile.php';
 $date = date("Y-m-d H:i:s");
 $u_fname =  $_POST["u_fname"];
 $u_address = $_POST["u_address"];
 $idnumber = $_POST["idnumber"];
 $u_mobile =  $_POST["u_mobile"];
 $u_email = $_POST["u_email"];
 $gross = $_POST["gross"];
 $designation = $_POST["designation"];
 
$sql = $conn->query("INSERT staffs(full_name, address, id_number, phone_no, email,gross,designation, date_reg) VALUES ('$u_fname','$u_address','$idnumber','$u_mobile','$u_email','$gross','$designation','$date')");

if( $sql) {
    echo   $status = 'ok';
  }
  else{
    echo      $status = 'err';
	
  }
 //echo $status;die; 
?>
