<?php
include '../depend/connectfile.php';
 $date = date("Y-m-d H:i:s");
 $name =  $_POST["name"];
 $idNo = $_POST["idNo"];
 $advance = $_POST["advance"];
 $paid = "0";

$sql = $conn->query("INSERT advancepay(name,idNo, advance, paid, datereceived) VALUES ('$name','$idNo','$advance','$paid','$date')");

if( $sql) {
    echo   $status = 'ok';
  }
  else{
    echo      $status = 'err';
	
  }
 //echo $status;die; 
?>