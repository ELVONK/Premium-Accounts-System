<?php 
include '../layout/header.php';
include '../depend/connectfile.php';
if($_GET["action"] == "v_view"){
     $id = $_GET["id"];
    $sql = $conn->query("SELECT * FROM shareholders WHERE indexx='$id'");
}
 ?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Shareholder Details  </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Shareholder profile</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">              
                <?php while ($account = mysqli_fetch_assoc($sql)) { ?>

              <h3 class="profile-username text-center"><?php print $account['full_name'];  ?></h3>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Full Name</b> <a class="pull-right"><?php print $account['full_name'];  ?></a>
                </li>
                <li class="list-group-item">
                  <b>Telephone</b> <a class="pull-right"><?php print $account['tel'];  ?></a>
               </li>                  
                <li class="list-group-item">
                  <b>Email</b> <a class="pull-right"><?php print $account['email'];  ?></a>
                </li>
                <?php } ?>
              </ul>             
            </div>
            <!-- /.box-body -->
          </div>
      </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">              
              <li class="active"><a href="#settings" data-toggle="tab">Vehicles</a></li>
            </ul>
            <div class="tab-content">

              <div class="active tab-pane" id="settings">
                    <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                      <th>#</th>
                                      <th>Make</th>
                                      <th>Plates</th>
                                      <th>Driver</th>
                                      <th>View</th>
                                      <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                     <?php	
            		                include '../depend/connectfile.php';
                                    $res=mysqli_query($conn, "SELECT  vehicles.make, vehicles.plates, drivers.driver_name 
                                    from vehicles 
                                    JOIN drivers ON drivers.indexx=vehicles.driver 
                                    where vehicles.owner='$id'");
            			            $i = 1;
            			            while ($account = mysqli_fetch_assoc($res)) { ?>
            			        <tr>
            		            	<td><?php echo $i; ?></td>
            		            	<td><?php echo $account['make']; ?></td>
            		            	<td><?php echo $account['plates']; ?></td>
            		                <td><?php echo $account['driver_name']; ?></td>
            						<td>		
            	                    <a  href="<?php echo 'editacccounts.php?action=v_view&id='; ?><?php echo $account['indexx']; ?>" ><i class="fa fa-eye"></i></a>
            	                    </td>
            	                    <td>		
            	                    <a onclick="return confirm('The Account will be deleted?')"  href="<?php echo 'bankdelete.php?action=v_view&id='; ?><?php echo $account['ID']; ?>" ><i style="color:red" class="fa fa-times"></i></a>
            	                    </td>
            		            </tr>
            		            <?php $i++; } ?>
                                </tbody>
                            </table>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->

    <!-- Modal -->

  </div>
<?php 
include '../layout/scripts.php';
include '../layout/footer.php';
 ?>
