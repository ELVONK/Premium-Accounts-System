<?php
include '../depend/connectfile.php';
 $date = date("Y-m-d H:i:s");
 $name =  $_POST["u_fname"];
 $tel = $_POST["u_mobile"];
 $email = $_POST["u_email"];
 
$sql = $conn->query("INSERT INTO shareholders( full_name, tel, email, date_time) VALUES ('$name', '$tel', '$email', '$date')");

if( $sql) {
       $status = 'ok';
  }
  else{
          $status = 'err';
	
  }
 //echo $status;die; 
?>
