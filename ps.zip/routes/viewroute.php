<?php 
include '../layout/header.php';
include '../depend/connectfile.php';
if($_GET["action"] == "v_view"){
     $id = $_GET["id"];
    $sql = $conn->query("SELECT * FROM route WHERE indexr='$id'");
}
 ?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Route Details  </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Route profile</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">              
                <?php while ($account = mysqli_fetch_assoc($sql)) { ?>

              <h3 class="profile-username text-center"><?php print $account['name'];  ?></h3>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Route Name</b> <a class="pull-right"><?php print $account['name'];  ?></a>
                </li>
                <li class="list-group-item">
                  <b>Distance</b> <a class="pull-right"><?php print $account['distance'];  ?></a>
               </li>                  
                <li class="list-group-item">
                  <b>Fare</b> <a class="pull-right"><?php print $account['fare'];  ?></a>
                </li>
                <?php } ?>
              </ul>             
            </div>
            <!-- /.box-body -->
          </div>
      </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">              
              <li class="active"><a href="#settings" data-toggle="tab">Routes</a></li>
            </ul>
            <div class="tab-content">

              <div class="active tab-pane" id="settings">
                    <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                      <th>#</th>
                                      <th>Name</th>
                                      <th>Distance</th>
                                      <th>Fare</th>
                                      <th>View</th>
                                      <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                     <?php	
            		                include '../depend/connectfile.php';
                                    $res=mysqli_query($conn, "SELECT  name, distance, fare from routes");
            			            $i = 1;
            			            while ($account = mysqli_fetch_assoc($res)) { ?>
            			        <tr>
            		            	<td><?php echo $i; ?></td>
            		            	<td><?php echo $account['name']; ?></td>
            		            	<td><?php echo $account['distance']; ?></td>
            		                <td><?php echo $account['fare']; ?></td>
            						<td>		
            	                    <a  href="<?php echo 'editacccounts.php?action=v_view&id='; ?><?php echo $account['indexr']; ?>" ><i class="fa fa-eye"></i></a>
            	                    </td>
            	                    <td>		
            	                    <a onclick="return confirm('The route will be deleted?')"  href="<?php echo 'bankdelete.php?action=v_view&id='; ?><?php echo $account['ID']; ?>" ><i style="color:red" class="fa fa-times"></i></a>
            	                    </td>
            		            </tr>
            		            <?php $i++; } ?>
                                </tbody>
                            </table>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->

    <!-- Modal -->

  </div>
<?php 
include '../layout/footer.php';
 ?>
