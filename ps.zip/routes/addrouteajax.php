<?php
include '../depend/connectfile.php';
 $date = date("Y-m-d H:i:s");
 $name =  $_POST["name"];
 $distance = $_POST["distance"];
 $fare = $_POST["fare"];
 
$sql = $conn->query("INSERT INTO routes( name, distance, fare, date_time) VALUES ('$name', '$distance', '$fare', '$date')");

if( $sql) {
       $status = 'ok';
  }
  else{
          $status = 'err';
	
  }
 //echo $status;die; 
?>