<?php //include 'layout/prof.php';?>
<?php 
session_start();

include 'layout/header.php';

include 'layout/leftbar.php';
 ?>


<div class="wrapper">
  	<div class="content-wrapper">
	    <section class="content-header">
	      <h1>
	        TRAVEL WITH US       
	      </h1>
	      <ol class="breadcrumb">
	        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i>WELCOME TO</a></li>
	        <li class="active">Premium Shuttle Limited</li>
	      </ol>
	    </section>
	    <!-- Main content -->
	    <section class="content">
	        <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12">
                  <div class="info-box">
                    <span class="info-box-icon bg-aqua"><i class="fa fa-money"></i></span>
        
                    <div class="info-box-content">
                      <span class="info-box-text">CLIENT SERVICE</span>
                      <span class="info-box-number">90<small>%</small></span>
                    </div>
                    <!-- /.info-box-content -->
                  </div>
                  <!-- /.info-box -->
                </div>
                <!-- /.col -->
                <div class="col-md-3 col-sm-6 col-xs-12">
                  <div class="info-box">
                    <span class="info-box-icon bg-red"><i class="fa fa-map"></i></span>
        
                    <div class="info-box-content">
                      <span class="info-box-text">PARCELDELIVERY</span>
                      <span class="info-box-number">41,410</span>
                    </div>
                    <!-- /.info-box-content -->
                  </div>
                  <!-- /.info-box -->
                </div>
                <!-- /.col -->
        
                <!-- fix for small devices only -->
                <div class="clearfix visible-sm-block"></div>
        
                <div class="col-md-3 col-sm-6 col-xs-12">
                  <div class="info-box">
                    <span class="info-box-icon bg-green"><i class="ion ion-ios-cart-outline"></i></span>
        
                    <div class="info-box-content">
                      <span class="info-box-text">SALE</span>
                      <span class="info-box-number">760</span>
                    </div>
                    <!-- /.info-box-content -->
                  </div>
                  <!-- /.info-box -->
                </div>
                <!-- /.col -->
                <div class="col-md-3 col-sm-6 col-xs-12">
                  <div class="info-box">
                    <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>
        
                    <div class="info-box-content">
                      <span class="info-box-text">CONTACT US</span>
                      <span class="info-box-number">2,000</span>
                    </div>
                    <!-- /.info-box-content -->
                  </div>
                  <!-- /.info-box -->
                </div>
                <!-- /.col -->
              </div>
	    	
	    </section>
	</div>
</div>
<?php 
include 'layout/scripts.php';
include 'layout/footer.php';
 ?>